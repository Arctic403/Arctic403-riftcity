# RiftCity V1

A single-player browser-first crime/RPG prototype designed to run on GitHub Pages.

## Deploy
1. Upload the contents of this folder to your GitHub repository.
2. Make sure `index.html` is in the repository root.
3. In GitHub: Settings → Pages → Deploy from branch → choose your main branch and `/ (root)`.
4. Open the generated GitHub Pages URL.

No build step or server is required for this V1. Progress is stored locally in the player's browser.
