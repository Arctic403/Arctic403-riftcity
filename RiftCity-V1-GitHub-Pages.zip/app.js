
const KEY="riftcity_v1_save";
let state=load();
let page="home";
function fresh(){return {name:"Rookie",cash:1000,bank:0,level:1,xp:0,hp:100,maxHp:100,energy:100,maxEnergy:100,inventory:["Phone"],wins:0,jobCount:0,created:false,feed:[
["🌃","Welcome to RiftCity.","Your story starts tonight."],
["📡","City Feed","The streets are active. Opportunities are everywhere."]
]}}
function load(){try{return JSON.parse(localStorage.getItem(KEY))||fresh()}catch{return fresh()}}
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function xpNeed(){return 100+(state.level-1)*75}
function addXP(n){state.xp+=n;while(state.xp>=xpNeed()){state.xp-=xpNeed();state.level++;state.maxHp+=8;state.maxEnergy+=5;state.hp=state.maxHp;state.energy=state.maxEnergy;state.feed.unshift(["⬆️","Level Up",`You reached level ${state.level}.`])}}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function render(){
 const xp=Math.round(state.xp/xpNeed()*100), en=Math.round(state.energy/state.maxEnergy*100), hp=Math.round(state.hp/state.maxHp*100);
 document.getElementById("app").innerHTML=`
 <header><div class="brand"><div class="logo">RIFT<span>CITY</span></div><button class="iconbtn" onclick="openProfile()">⚙️</button></div></header>
 <main>${page==="home"?home(hp,en,xp):page==="city"?city():page==="character"?character():feed()}</main>
 <nav class="nav">
  <button class="${page==="home"?"active":""}" onclick="go('home')"><span>⌂</span>Home</button>
  <button class="${page==="city"?"active":""}" onclick="go('city')"><span>◈</span>City</button>
  <button class="${page==="character"?"active":""}" onclick="go('character')"><span>♙</span>You</button>
  <button class="${page==="feed"?"active":""}" onclick="go('feed')"><span>◉</span>Feed</button>
 </nav>`;
}
function home(hp,en,xp){return `
 <section class="hero"><div class="eyebrow">Downtown • 11:42 PM</div><h1>Welcome back, ${esc(state.name)}.</h1><div class="muted">The city is yours to figure out.</div>
 <div class="stats"><div class="stat"><b class="money">$${state.cash.toLocaleString()}</b><small>Cash</small></div><div class="stat"><b>Lv ${state.level}</b><small>Level</small></div><div class="stat"><b>${state.wins}</b><small>Wins</small></div></div>
 <div style="margin-top:15px"><div class="row"><small>Health</small><small>${state.hp}/${state.maxHp}</small></div><div class="bar"><i style="width:${hp}%"></i></div></div>
 <div style="margin-top:10px"><div class="row"><small>Energy</small><small>${state.energy}/${state.maxEnergy}</small></div><div class="bar"><i style="width:${en}%"></i></div></div>
 <div style="margin-top:10px"><div class="row"><small>XP</small><small>${state.xp}/${xpNeed()}</small></div><div class="bar"><i style="width:${xp}%"></i></div></div></section>
 <section class="section"><div class="sectionhead"><h2>WHAT DO YOU WANT TO DO?</h2></div><div class="grid">
 ${action("💼","Find Work","Earn cash","jobs")}
 ${action("👊","Hit the Streets","Fight for rewards","fight")}
 ${action("🏦","Bank","Protect your money","bank")}
 ${action("🛒","Market","Buy useful gear","market")}
 </div></section>
 <section class="section"><div class="sectionhead"><h2>RIFTCITY FEED</h2><button class="secondary" onclick="go('feed')">View all</button></div>${state.feed.slice(0,3).map(f=>`<div class="feed"><div class="feedicon">${f[0]}</div><div><b>${esc(f[1])}</b><div class="muted" style="font-size:13px">${esc(f[2])}</div></div></div>`).join("")}</section>`}
function action(icon,title,sub,type){return `<button class="action" onclick="openAction('${type}')"><div class="emoji">${icon}</div><b>${title}</b><small>${sub}</small></button>`}
function city(){return `<section class="hero"><div class="eyebrow">RiftCity Map</div><h1>The City</h1><div class="muted">Every district has an opportunity. Some have consequences.</div></section>
<section class="section"><div class="grid">
${action("🏙️","Downtown","Shops, jobs, nightlife","jobs")}${action("🏭","Industrial","Scrap, risk, money","jobs")}${action("🌃","Nightlife","Events and contacts","market")}${action("🚓","Police District","Recovery and trouble","hospital")}${action("🏦","Financial","Bank and investments","bank")}${action("🏠","Your Apartment","Inventory and character","character")}
</div></section>`}
function character(){return `<section class="hero"><div class="eyebrow">Your Character</div><h1>${esc(state.name)}</h1><div class="muted">Level ${state.level} • ${state.wins} victories</div></section>
<section class="section cards"><div class="card"><div class="row"><b>Wallet</b><b class="money">$${state.cash.toLocaleString()}</b></div><div class="row"><span class="muted">Bank</span><span>$${state.bank.toLocaleString()}</span></div></div>
<div class="card"><h3>Inventory</h3><p>${state.inventory.map(esc).join(" • ")}</p></div>
<div class="card"><h3>Progress</h3><p>${state.jobCount} jobs completed. ${state.wins} street fights won.</p></div></section>`}
function feed(){return `<section class="hero"><div class="eyebrow">Live City Feed</div><h1>What's happening</h1><div class="muted">The city never really sleeps.</div></section><section class="section">${state.feed.map(f=>`<div class="feed"><div class="feedicon">${f[0]}</div><div><b>${esc(f[1])}</b><div class="muted" style="font-size:13px">${esc(f[2])}</div></div></div>`).join("")}</section>`}
function go(p){page=p;render();scrollTo(0,0)}
function openProfile(){show(`<div class="row"><h2>RiftCity Settings</h2><button class="secondary" onclick="closeModal()">✕</button></div><p class="muted">Your save is stored in this browser.</p><label class="muted">Character name</label><input id="nameInput" value="${esc(state.name)}"><button class="primary" onclick="rename()">Save Name</button><button class="choice danger" onclick="resetGame()">Reset Save</button>`)}
function rename(){let n=document.getElementById("nameInput").value.trim();if(n){state.name=n;save();closeModal();render()}}
function resetGame(){if(confirm("Reset your RiftCity save?")){state=fresh();save();closeModal();render()}}
function openAction(type){
 if(type==="jobs") return jobs();
 if(type==="fight") return fights();
 if(type==="bank") return bank();
 if(type==="market") return market();
 if(type==="hospital") return hospital();
 if(type==="character") return go("character");
}
function jobs(){show(`<div class="row"><h2>Available Work</h2><button class="secondary" onclick="closeModal()">✕</button></div><p class="muted">Spend energy to earn money and XP.</p>${RIFT_DATA.jobs.map(j=>`<button class="choice" onclick="doJob('${j.id}')"><div class="row"><b>${j.name}</b><b class="money">$${j.pay}</b></div><small class="muted">${j.desc}<br>⚡ ${j.energy} energy • +${j.xp} XP</small></button>`).join("")}`)}
function doJob(id){let j=RIFT_DATA.jobs.find(x=>x.id===id);if(state.energy<j.energy)return alert("Not enough energy.");state.energy-=j.energy;let risky=Math.random()<j.risk;if(risky){let loss=Math.min(state.cash,Math.floor(j.pay*.5));state.cash+=j.pay-loss;addXP(Math.floor(j.xp*.6));state.feed.unshift(["⚠️","Job went sideways",`You escaped with $${j.pay-loss}.`])}else{state.cash+=j.pay;addXP(j.xp);state.feed.unshift(["💼","Job complete",`You earned $${j.pay}.`])}state.jobCount++;save();closeModal();render()}
function fights(){show(`<div class="row"><h2>Street Fight</h2><button class="secondary" onclick="closeModal()">✕</button></div><p class="muted">Pick an opponent. Combat is quick in V1.</p>${RIFT_DATA.enemies.map((e,i)=>`<button class="choice" onclick="fight(${i})"><div class="row"><b>${e.name}</b><span class="danger">${e.hp} HP</span></div><small class="muted">Attack ${e.attack} • Reward $${e.reward} • +${e.xp} XP</small></button>`).join("")}`)}
function fight(i){let e=RIFT_DATA.enemies[i];if(state.energy<10)return alert("You need 10 energy to fight.");state.energy-=10;let playerPower=state.level*22+Math.floor(Math.random()*35), enemyPower=e.hp+Math.floor(Math.random()*25);if(playerPower>=enemyPower){state.cash+=e.reward;state.wins++;addXP(e.xp);state.feed.unshift(["👊","Victory",`You beat ${e.name} and earned $${e.reward}.`])}else{let dmg=e.attack+Math.floor(Math.random()*9);state.hp-=dmg;if(state.hp<=0){state.hp=1;state.cash=Math.max(0,state.cash-100);state.feed.unshift(["🚑","Knocked out",`You lost $100 getting patched up.`])}else state.feed.unshift(["🥊","Tough loss",`${e.name} hit you for ${dmg}.`])}save();closeModal();render()}
function bank(){show(`<div class="row"><h2>Bank</h2><button class="secondary" onclick="closeModal()">✕</button></div><div class="notice">Cash: <b>$${state.cash.toLocaleString()}</b> · Bank: <b>$${state.bank.toLocaleString()}</b></div><button class="choice" onclick="deposit()">Deposit $250</button><button class="choice" onclick="withdraw()">Withdraw $250</button>`)}
function deposit(){let n=Math.min(250,state.cash);state.cash-=n;state.bank+=n;save();closeModal();render()}
function withdraw(){let n=Math.min(250,state.bank);state.bank-=n;state.cash+=n;save();closeModal();render()}
function market(){show(`<div class="row"><h2>Market</h2><button class="secondary" onclick="closeModal()">✕</button></div><p class="muted">Simple starter inventory for V1.</p><button class="choice" onclick="buy('Med Kit',150)">🩹 <b>Med Kit</b><br><small class="muted">$150 • Restore 35 health</small></button><button class="choice" onclick="buy('Energy Drink',100)">⚡ <b>Energy Drink</b><br><small class="muted">$100 • Restore 30 energy</small></button>`)}
function buy(item,cost){if(state.cash<cost)return alert("Not enough cash.");state.cash-=cost;state.inventory.push(item);if(item==="Med Kit")state.hp=Math.min(state.maxHp,state.hp+35);if(item==="Energy Drink")state.energy=Math.min(state.maxEnergy,state.energy+30);state.feed.unshift(["🛒","Purchase",`You bought ${item}.`]);save();closeModal();render()}
function hospital(){show(`<div class="row"><h2>Hospital</h2><button class="secondary" onclick="closeModal()">✕</button></div><p class="muted">Get patched up and get back into the city.</p><button class="primary" onclick="heal()">Recover for $100</button>`)}
function heal(){if(state.cash<100)return alert("You need $100.");state.cash-=100;state.hp=state.maxHp;state.energy=Math.min(state.maxEnergy,state.energy+20);save();closeModal();render()}
function show(body){let m=document.createElement("div");m.className="modal";m.id="modal";m.innerHTML=`<div class="sheet">${body}</div>`;document.body.appendChild(m)}
function closeModal(){document.getElementById("modal")?.remove()}
if(!state.created){show(`<div class="eyebrow">Welcome to RiftCity</div><h1>Create your character</h1><p class="muted">This is your city. Start small. Build something.</p><input id="firstName" placeholder="Character name" maxlength="20"><button class="primary" onclick="startGame()">Enter RiftCity</button>`)}
function startGame(){let n=document.getElementById("firstName").value.trim()||"Rookie";state.name=n;state.created=true;state.feed.unshift(["🚪","New arrival",`${n} has entered RiftCity.`]);save();closeModal();render()}
render();
