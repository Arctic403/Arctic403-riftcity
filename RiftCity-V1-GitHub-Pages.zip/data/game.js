
window.RIFT_DATA = {
  jobs:[
    {id:"delivery",name:"Night Delivery",desc:"Move a sealed package across the city.",pay:180,xp:35,energy:8,risk:0.08},
    {id:"bartender",name:"Bartender Shift",desc:"Work the late shift at a downtown bar.",pay:120,xp:25,energy:6,risk:0.03},
    {id:"scrap",name:"Scrap Run",desc:"Search the Industrial District for useful parts.",pay:260,xp:50,energy:12,risk:0.13},
    {id:"hustle",name:"Street Hustle",desc:"Take a risky opportunity from a local fixer.",pay:420,xp:80,energy:18,risk:0.20}
  ],
  enemies:[
    {name:"Street Punk",hp:55,attack:9,reward:90,xp:30},
    {name:"Dock Enforcer",hp:85,attack:13,reward:180,xp:55},
    {name:"Rival Runner",hp:120,attack:17,reward:300,xp:85}
  ]
};
